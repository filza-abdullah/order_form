To install DBMS for Khurshid Soap Chemicals and Oil Industry, 

1. Extract Setup.zip file
2. Go to Debug Folder
3. Run setup.exe
4. Follow the instructions.